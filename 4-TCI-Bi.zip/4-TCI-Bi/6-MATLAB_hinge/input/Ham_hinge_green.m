function [H00,H01x,H01y]=Ham_hinge_green(kz,LX,LY,LZ,N_HAM,HAM_R,xcut,ycut)

li=1*i;

%% GET the hopping in x direction

% find LZ=0 for extracting H0 
index_x=find(LX(1,:)==0);
index_y=find(LY(1,:)==0);
index=intersect(index_x,index_y);
h0=exp(li*(LZ(:,index)*kz)).*HAM_R(:,index);
H0=reshape(sum(h0,2),N_HAM,N_HAM);
H0=(H0'+H0)/2;  % Hermite matrix


% find LZ=iz for extracting T(iz) of the iz order of neighbors
xmax=max(max(LX));
ymax=max(max(LY));
if xcut>xmax
    xmax=xcut;
end
if ycut>ymax
    ymax=ycut;
end
T=zeros(2*xmax+1,2*ymax+1,N_HAM,N_HAM);

for ix=-xmax:xmax
    for iy=-ymax:ymax
        index_x=find(LX(1,:)==ix);
        index_y=find(LY(1,:)==iy);
        index1=intersect(index_x,index_y);
        t=exp(li*(LZ(:,index1)*kz)).*HAM_R(:,index1);
        T(ix+1+xmax,iy+1+ymax,:,:)=reshape(sum(t,2),N_HAM,N_HAM);
    end
end

%% construct H00
H00=kron(eye((xcut+1)*(ycut+1)),H0);
H01x=kron(eye((xcut+1)*(ycut+1)),zeros(N_HAM,N_HAM));
H01y=kron(eye((xcut+1)*(ycut+1)),zeros(N_HAM,N_HAM));

for ix=0:xcut
    for iy=0:ycut
        ih=ix*(ycut+1)+iy;
        
        for ix1=0:xcut
            for iy1=0:ycut
                ih1 = ix1*(ycut+1)+iy1;
                ixx=ix1-ix;
                iyy=iy1-iy;
                if ih1>ih
                    TT=reshape(T(ixx+1+xmax,iyy+1+ymax,:,:),N_HAM,N_HAM);
                    H00(1+ih*N_HAM:(ih+1)*N_HAM,1+ih1*N_HAM:(ih1+1)*N_HAM)=TT;
                    H00(1+ih1*N_HAM:(ih1+1)*N_HAM,1+ih*N_HAM:(ih+1)*N_HAM)=TT';
                end
                if ixx+(xcut+1)<=xmax
                    TTx=reshape(T(ixx+(xcut+1)+1+xmax,iyy+1+ymax,:,:),N_HAM,N_HAM);
                    H01x(1+ih*N_HAM:(ih+1)*N_HAM,1+ih1*N_HAM:(ih1+1)*N_HAM)=TTx;
                end
                if iyy+(ycut+1)<=ymax
                    TTy=reshape(T(ixx+1+xmax,iyy+(ycut+1)+1+ymax,:,:),N_HAM,N_HAM);
                    H01y(1+ih*N_HAM:(ih+1)*N_HAM,1+ih1*N_HAM:(ih1+1)*N_HAM)=TTy;
                end
                
            end                
        end
    end
end

end