% Green function method
% ref. 1984
%% READ the wannier hamiltonian
clear all;
li=i;
eta=1e-4;
epsilon=1e-4;
Nvalence = 12;

disp('Start reading wannier90_hr.dat');
tic;

filehr = fopen('./wannier90_hr.dat');
head=textscan(filehr,'%s %s %s %s %s',1);
n_ham=textscan(filehr,'%d',1);
N_HAM=cell2mat(n_ham);           %dimensions of the HAM
n_latt=textscan(filehr,'%d',1);  %total number of neighboring sites
N_LATT=cell2mat(n_latt);
% degeneracy of a site, HAM_R should be scaled by 1/DGN.
dgn=textscan(filehr,'%f',N_LATT); 
DGN=cell2mat(dgn)'; % DNG is a row matrix
% read LX,LY,LZ,HAM_R(real,img), and omit (n,m) of HAM_R_nm
data=textscan(filehr,'%f %f %f %*d %*d %10.6f %10.6f',N_HAM*N_HAM*N_LATT);
DATA=cell2mat(data); 
HAM_R1=DATA(:,4)+1i*DATA(:,5);
HAM_R=reshape(HAM_R1, N_HAM*N_HAM,N_LATT);
HAM_R=HAM_R./kron(ones(N_HAM*N_HAM,1),DGN);
Lx=reshape(DATA(:,1),N_HAM*N_HAM,N_LATT);
Ly=reshape(DATA(:,2),N_HAM*N_HAM,N_LATT);
Lz=reshape(DATA(:,3),N_HAM*N_HAM,N_LATT);
fclose(filehr);
disp('Complete reading the Hamiltonian from wannier90_hr.dat');
toc;

LX=Lx; 
LY=Ly;
LZ=Lz;
%LX=Ly; 
%LY=Lx;
%% Calculate the surface states using Green function method
kline=[ 0.0000  0.0000   -0.50
        0.0000  0.0000   -0.00
                    ]*2*pi;
Ngrid=500;
Ef = 5.2558;

Kline=zeros((size(kline,1)-1)*(Ngrid-1)+1,3);
for ikline=1:(size(kline,1)-1)
    tmp=linspaceNDim(kline(ikline,:),kline(ikline+1,:),Ngrid);
    tmp2=tmp';
    Kline((ikline-1)*(Ngrid-1)+1:ikline*(Ngrid-1),:)=tmp2(1:Ngrid-1,:);
end
Kline((size(kline,1)-1)*(Ngrid-1)+1,:)=kline(size(kline,1),:);

xcut=0;
ycut=6;
Energy=Ef-0.3:0.0002:Ef+0.3;
DOS=zeros(size(Energy));
LDOS=zeros(size(Energy,2),size(Kline,1));

for ik=1:size(Kline,1)
    kz=Kline(ik,3); 
    
    [H00,H01x,H01y]=Ham_hinge_green(kz,LX,LY,LZ,N_HAM,HAM_R,xcut,ycut);
    II=eye(size(H00));
    loop=10; % maximum loop for iterations of T matrix
    
    for index=1:size(Energy,2)
        tSTART=tic;
        omega=II*(Energy(index)+li*eta);
         
        H01=H01x;
        % initialize
        tmp_inverse=II/(omega-H00);
        tau0=tmp_inverse*H01';
        taut0=tmp_inverse*H01;
        tmp_inverse=II/(II-tau0*taut0-taut0*tau0);
        tau=tmp_inverse*tau0^2;
        taut=tmp_inverse*taut0^2;
        tot=tau0;
        tsum=taut0;
        
        for lp=1:loop
            tot=tot+tsum*tau;
            tsum=tsum*taut;
            tau_old=tau;
            taut_old=taut;
            tmp_inverse=II/(II-tau_old*taut_old-taut_old*tau_old);
            tau=tmp_inverse*tau_old^2;
            taut=tmp_inverse*taut_old^2;
            cnvg_tau=sum(sum(abs(tau),1),2);
            cnvg_taut=sum(sum(abs(taut),1),2);
            if ((cnvg_tau<1e-7) && (cnvg_taut<1e-7))
                break;
            end
        end
        Gx=II/(omega-H00-H01*tot);
        DOS(index)=-1/pi*imag(trace(Gx));   
        
        message = sprintf('k-point:%d/%d, Time:%6.2f second',(ik-1)*size(Energy,2)+index,size(Kline,1)*size(Energy,2),toc(tSTART));
        disp(message);
    end
    LDOS(:,ik)=DOS;
end

%% plot and save data
kpath=0:2*(size(Kline,1)-1)+1;
[kmesh,Emesh]=meshgrid(kpath,Energy-Ef);
LDOS2=[fliplr(LDOS),LDOS];

figure
h=pcolor(kmesh,Emesh,LDOS2); 
set(h,'edgecolor','none');
caxis([0 40]);
ylabel("Energy (eV)");
xticks([0 (size(kpath,2)-1)/2 (size(kpath,2)-1)]); 
xticklabels({' -Z ', ' \Gamma ',' Z '});
set(gca,'FontName','Times New Roman','FontSize', 18,'fontweight','b')
savefig('LDOS.fig');

filename = ['LDOS','.txt'];
save(filename, 'LDOS','-ascii');