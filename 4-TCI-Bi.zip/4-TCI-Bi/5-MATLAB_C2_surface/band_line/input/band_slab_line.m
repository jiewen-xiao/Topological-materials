% Green function method
% ref. 1984
%% READ the wannier hamiltonian
clear all;
li=i;
eta=1e-5;
epsilon=1e-6;

zcut=30;
Nvalence = 6*(zcut+1);

disp('Start reading wannier90_hr.dat');
tic;

filehr = fopen('./wannier90_hr.dat');
head=textscan(filehr,'%s %s %s %s %s',1);
n_ham=textscan(filehr,'%d',1);
N_HAM=cell2mat(n_ham);           %dimensions of the HAM
n_latt=textscan(filehr,'%d',1);  %total number of neighboring sites
N_LATT=cell2mat(n_latt);
% degeneracy of a site, HAM_R should be scaled by 1/DGN.
dgn=textscan(filehr,'%f',N_LATT); 
DGN=cell2mat(dgn)'; % DNG is a row matrix
% read LX,LY,LZ,HAM_R(real,img), and omit (n,m) of HAM_R_nm
data=textscan(filehr,'%f %f %f %*d %*d %10.6f %10.6f',N_HAM*N_HAM*N_LATT);
DATA=cell2mat(data); 
HAM_R1=DATA(:,4)+1i*DATA(:,5);
HAM_R=reshape(HAM_R1, N_HAM*N_HAM,N_LATT);
HAM_R=HAM_R./kron(ones(N_HAM*N_HAM,1),DGN);
Lx=reshape(DATA(:,1),N_HAM*N_HAM,N_LATT);
Ly=reshape(DATA(:,2),N_HAM*N_HAM,N_LATT);
Lz=reshape(DATA(:,3),N_HAM*N_HAM,N_LATT);
fclose(filehr);
disp('Complete reading the Hamiltonian from wannier90_hr.dat');
toc;

%% make a rotation around x axis, cut 
%  then new xy plane corresponding to old zx plane
LX=Lx;
LY=Ly;
LZ=Lz;
%% TEST: Calculate the bulk band structure 
kline=[  -0.1818  -0.5000   0.000;  
          0.0000   0.0000   0.000;
          0.1818   0.5000   0.000;
          0.5000   0.5000   0.000;]*2*pi;

% kline=[  -0.5000  -0.0645   0.000;      
%           0.0000   0.0000   0.000; 
%          -0.5000  -0.0645   0.000;  ]*2*pi;

Ngrid=201;
Kline=zeros((size(kline,1)-1)*(Ngrid-1)+1,3);
for ikline=1:(size(kline,1)-1)
    tmp=linspaceNDim(kline(ikline,:),kline(ikline+1,:),Ngrid);
    tmp2=tmp';
    Kline((ikline-1)*(Ngrid-1)+1:ikline*(Ngrid-1),:)=tmp2(1:Ngrid-1,:);
end
Kline((size(kline,1)-1)*(Ngrid-1)+1,:)=kline(size(kline,1),:);

N_HAM_slab = N_HAM*(zcut+1);
Ek=zeros((size(kline,1)-1)*(Ngrid-1)+1,N_HAM_slab);

for ik=1:size(Kline,1)
    tSTART=tic;
        
    kx=Kline(ik,1);
    ky=Kline(ik,2);
    kz=Kline(ik,3);
    
    H_tb = Ham_slab(kx,ky,LX,LY,LZ,N_HAM,HAM_R,zcut);
    Hk=(H_tb'+H_tb)/2; 
        
    [Wavek,energy_tmp]=eig(Hk);
    energy=diag(energy_tmp);
    Ek(ik,:)=energy';
        
    message = sprintf('k-point:%3d/%3d, Time:%6.2f second',ik,size(Kline,1),toc(tSTART));
    disp(message);
end
Ef = (max(Ek(:,Nvalence))+min(Ek(:,Nvalence+1)))/2; % center of CBM+VBM
%%
figure
for iband=1:N_HAM_slab
    M = plot(0:(size(Ek,1)-1),Ek(:,iband)-Ef,'b');hold on;
    set(M,'linewidth',2);
end
axis([0 size(Ek,1)-1 -0.55  +0.55]);
yticks([-0.5 0.0 0.5]); 
box on;
xticks([0 (size(Ek,1)-1)/3 2*(size(Ek,1)-1)/3 (size(Ek,1)-1)]);
xticklabels({'P_2', '\Gamma', 'P_1', 'M'});
ylabel('Energy (eV)'); 
set(gca,'FontName','Times New Roman','FontSize', 15);
savefig('band_line');
%% the zoom in band structure
DP1 = [-0.0567   -0.1558 0]; n1 = DP1/norm(DP1);
DP2 = [-0.0647   -0.0083 0]; n2 = DP2/norm(DP2);
%DP1
kline=[  DP1-0.005*n1;  
         DP1+0.005*n1]*2*pi;

Ngrid=1001;
Kline=zeros((size(kline,1)-1)*(Ngrid-1)+1,3);
for ikline=1:(size(kline,1)-1)
    tmp=linspaceNDim(kline(ikline,:),kline(ikline+1,:),Ngrid);
    tmp2=tmp';
    Kline((ikline-1)*(Ngrid-1)+1:ikline*(Ngrid-1),:)=tmp2(1:Ngrid-1,:);
end
Kline((size(kline,1)-1)*(Ngrid-1)+1,:)=kline(size(kline,1),:);

N_HAM_slab = N_HAM*(zcut+1);
Ek1=zeros((size(kline,1)-1)*(Ngrid-1)+1,N_HAM_slab);

for ik=1:size(Kline,1)
    tSTART=tic;
        
    kx=Kline(ik,1);
    ky=Kline(ik,2);
    kz=Kline(ik,3);
    
    H_tb = Ham_slab(kx,ky,LX,LY,LZ,N_HAM,HAM_R,zcut);
    Hk=(H_tb'+H_tb)/2; 
        
    [Wavek,energy_tmp]=eig(Hk);
    energy=diag(energy_tmp);
    Ek1(ik,:)=energy';
        
    message = sprintf('k-point:%3d/%3d, Time:%6.2f second',ik,size(Kline,1),toc(tSTART));
    disp(message);
end
Ef = (max(Ek1(:,Nvalence))+min(Ek1(:,Nvalence+1)))/2; % center of CBM+VBM

% DP2
kline=[  DP2-0.005*n1;  
         DP2+0.005*n1]*2*pi;

Ngrid=1001;
Kline=zeros((size(kline,1)-1)*(Ngrid-1)+1,3);
for ikline=1:(size(kline,1)-1)
    tmp=linspaceNDim(kline(ikline,:),kline(ikline+1,:),Ngrid);
    tmp2=tmp';
    Kline((ikline-1)*(Ngrid-1)+1:ikline*(Ngrid-1),:)=tmp2(1:Ngrid-1,:);
end
Kline((size(kline,1)-1)*(Ngrid-1)+1,:)=kline(size(kline,1),:);

N_HAM_slab = N_HAM*(zcut+1);
Ek2=zeros((size(kline,1)-1)*(Ngrid-1)+1,N_HAM_slab);

for ik=1:size(Kline,1)
    tSTART=tic;
        
    kx=Kline(ik,1);
    ky=Kline(ik,2);
    kz=Kline(ik,3);
    
    H_tb = Ham_slab(kx,ky,LX,LY,LZ,N_HAM,HAM_R,zcut);
    Hk=(H_tb'+H_tb)/2; 
        
    [Wavek,energy_tmp]=eig(Hk);
    energy=diag(energy_tmp);
    Ek2(ik,:)=energy';
        
    message = sprintf('k-point:%3d/%3d, Time:%6.2f second',ik,size(Kline,1),toc(tSTART));
    disp(message);
end
Ef = (max(Ek2(:,Nvalence))+min(Ek2(:,Nvalence+1)))/2; % center of CBM+VBM
%%
figure
subplot(1,2,1)
for iband=1:N_HAM_slab
    M = plot(0:(size(Ek1,1)-1),Ek1(:,iband)-Ef,'b');hold on;
    set(M,'linewidth',2);
end
axis([0 size(Ek1,1)-1 -0.015  +0.015]);
yticks([-0.01 0.0 0.01]); 
box on;
xticks([0 (size(Ek1,1)-1)/2 (size(Ek1,1)-1)]);
xticklabels({'P_2', 'DP_1', 'P_1'});
ylabel('Energy (eV)'); 
set(gca,'FontName','Times New Roman','FontSize', 15);

subplot(1,2,2)
for iband=1:N_HAM_slab
    M = plot(0:(size(Ek2,1)-1),Ek2(:,iband)-Ef,'b');hold on;
    set(M,'linewidth',2);
end
axis([0 size(Ek2,1)-1 -0.015  +0.015]);
yticks([-0.01 0.0 0.01]); 
box on;
xticks([0 (size(Ek2,1)-1)/2 (size(Ek2,1)-1)]);
xticklabels({'P_2`', 'DP_2', 'P_1`'});
ylabel('Energy (eV)'); 
set(gca,'FontName','Times New Roman','FontSize', 15);

savefig('band_zoom_in');