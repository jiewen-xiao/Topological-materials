function [H_tb]=Ham_slab(kx,ky,LX,LY,LZ,N_HAM,HAM_R,zcut)

li=1*i;

%% GET the hopping in x direction

% find LZ=0 for extracting H0 
index=find(LZ(1,:)==0);
h0=exp(li*(LX(:,index)*kx+LY(:,index)*ky)).*HAM_R(:,index);
H0=reshape(sum(h0,2),N_HAM,N_HAM);
H0=(H0'+H0)/2;  % Hermite matrix


% find LZ=iz for extracting T(iz) of the iz order of neighbors
zmax=max(LZ(:));
zmin=min(LZ(:));
if zmax+zmin ~= 0
    disp('problem: zmax+zmin ~= 0 !!');
    return;
end

T=zeros(zmax+1,N_HAM,N_HAM);

for iz=0:zmax
    index=find(LZ(1,:)==iz);
    t=exp(li*(LX(:,index)*kx+LY(:,index)*ky)).*HAM_R(:,index);
    T(iz+1,:,:)=reshape(sum(t,2),N_HAM,N_HAM);
end

%% construct H00 and H01
H_tb=kron(eye(zcut+1),H0);

for iz=1:zmax
    if iz<=zcut
        tmp=diag(ones((zcut+1-iz),1),iz);
        TT=reshape(T(iz+1,:,:),N_HAM,N_HAM);
        H_tb=H_tb+kron(tmp,TT)+kron(tmp',TT');
    end
end

%for iz=0:zcut    
%    for iz1=0:zcut
%        iz2=iz+iz1;
%        if iz2 <= zcut
%            H_tb(iz*N_HAM+1:(iz+1)*N_HAM,iz2*N_HAM+1:(iz2+1)*N_HAM)=reshape(T(iz2+1,:,:),N_HAM,N_HAM);
%            H_tb(iz2*N_HAM+1:(iz2+1)*N_HAM,iz*N_HAM+1:(iz+1)*N_HAM)=conj(reshape(T(iz2+1,:,:),N_HAM,N_HAM));
%        end
%    end
%end


end