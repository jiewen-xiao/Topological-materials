% Green function method
% ref. 1984
%% READ the wannier hamiltonian
clear all;
li=i;
eta=1e-5;
epsilon=1e-6;

zcut=30;
Nvalence = 6*(zcut+1);

disp('Start reading wannier90_hr.dat');
tic;

filehr = fopen('./wannier90_hr.dat');
head=textscan(filehr,'%s %s %s %s %s',1);
n_ham=textscan(filehr,'%d',1);
N_HAM=cell2mat(n_ham);           %dimensions of the HAM
n_latt=textscan(filehr,'%d',1);  %total number of neighboring sites
N_LATT=cell2mat(n_latt);
% degeneracy of a site, HAM_R should be scaled by 1/DGN.
dgn=textscan(filehr,'%f',N_LATT); 
DGN=cell2mat(dgn)'; % DNG is a row matrix
% read LX,LY,LZ,HAM_R(real,img), and omit (n,m) of HAM_R_nm
data=textscan(filehr,'%f %f %f %*d %*d %10.6f %10.6f',N_HAM*N_HAM*N_LATT);
DATA=cell2mat(data); 
HAM_R1=DATA(:,4)+1i*DATA(:,5);
HAM_R=reshape(HAM_R1, N_HAM*N_HAM,N_LATT);
HAM_R=HAM_R./kron(ones(N_HAM*N_HAM,1),DGN);
Lx=reshape(DATA(:,1),N_HAM*N_HAM,N_LATT);
Ly=reshape(DATA(:,2),N_HAM*N_HAM,N_LATT);
Lz=reshape(DATA(:,3),N_HAM*N_HAM,N_LATT);
fclose(filehr);
disp('Complete reading the Hamiltonian from wannier90_hr.dat');
toc;

%% make a rotation around x axis, cut 
%  then new xy plane corresponding to old zx plane
LX=Lx;
LY=Ly;
LZ=Lz;

%% 2D band
nKmesh=250;
[kx,ky]=meshgrid(0:1/nKmesh:1);
kx=kx*pi;
ky=ky*pi;

Eband=zeros(size(kx,1),size(ky,2),N_HAM_slab);

for ik1=1:size(kx,1)
    tSTART=tic;
    for ik2=1:size(ky,2)
        k1=kx(ik1,ik2);
        k2=ky(ik1,ik2);
        
        H_tb = Ham_slab(k1,k2,LX,LY,LZ,N_HAM,HAM_R,zcut);
        Hamk=(H_tb'+H_tb)/2;
        
        [Wavek,energy_tmp]=eig(Hamk);
        energy=diag(energy_tmp)';
        Eband(ik1,ik2,:)=energy;
    end
    message = sprintf('k-point:%3d/%3d, Time:%6.2f second',ik1,size(kx,1),toc(tSTART));
    disp(message);
end

figure
surf(kx,ky,Eband(:,:,Nvalence+1)-Eband(:,:,Nvalence));
%surf(kx,ky,Eband(:,:,Nvalence+1));
shading interp;
colorbar;
set(gca,'FontName','Times New Roman','FontSize', 16,'fontweight','b');
savefig('band_2D1.fig');

%% save data
Ek_CB2=Eband(:,:,Nvalence+2);
filename1 = ['Ek_CB2','.txt'];
save(filename1, 'Ek_CB2','-ascii');

Ek_CB1=Eband(:,:,Nvalence+1);
filename2 = ['Ek_CB1','.txt'];
save(filename2, 'Ek_CB1','-ascii');

Ek_VB1=Eband(:,:,Nvalence);
filename3 = ['Ek_VB1','.txt'];
save(filename3, 'Ek_VB1','-ascii');

Ek_VB2=Eband(:,:,Nvalence-1);
filename4 = ['Ek_VB2','.txt'];
save(filename4, 'Ek_VB2','-ascii');
