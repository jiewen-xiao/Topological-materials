% Green function method
% ref. 1984
%% READ the wannier hamiltonian
clear all;
li=i;
eta=1e-4;
epsilon=1e-4;

N_HAM = 48;
[HAM_R,LX,LY,LZ] = hamk1();
Ef = 0;
Nvalence = 24;
%% Calculate the surface states using Green function method
kline=[ 0.0000  0.0000   -0.500
        0.0000  0.0000   -0.495
                    ]*2*pi;
Ngrid=11;

Kline=zeros((size(kline,1)-1)*(Ngrid-1)+1,3);
for ikline=1:(size(kline,1)-1)
    tmp=linspaceNDim(kline(ikline,:),kline(ikline+1,:),Ngrid);
    tmp2=tmp';
    Kline((ikline-1)*(Ngrid-1)+1:ikline*(Ngrid-1),:)=tmp2(1:Ngrid-1,:);
end
Kline((size(kline,1)-1)*(Ngrid-1)+1,:)=kline(size(kline,1),:);

xcut=7;
ycut=0;
ih=(xcut+1)*(ycut+1);
Energy=Ef-0.25:0.0001:Ef+0.25;
DOS=zeros(size(Energy));
LDOS=zeros(size(Energy,2),size(Kline,1));
% DOS_proj=zeros(size(Energy,2),8*ih);
% LDOS_proj=zeros(size(Energy,2),8*ih,size(Kline,1));

for ik=1:size(Kline,1)
    kz=Kline(ik,3); 
    
    [H00,H01x,H01y]=Ham_hinge_green(kz,LX,LY,LZ,N_HAM,HAM_R,xcut,ycut);
    II=eye(size(H00));
    loop=10; % maximum loop for iterations of T matrix
    
    for index=1:size(Energy,2)
        tSTART=tic;
        omega=II*(Energy(index)+li*eta);
         
        H01=H01y;
        % initialize
        tmp_inverse=II/(omega-H00);
        tau0=tmp_inverse*H01';
        taut0=tmp_inverse*H01;
        tmp_inverse=II/(II-tau0*taut0-taut0*tau0);
        tau=tmp_inverse*tau0^2;
        taut=tmp_inverse*taut0^2;
        tot=tau0;
        tsum=taut0;
        
        for lp=1:loop
            tot=tot+tsum*tau;
            tsum=tsum*taut;
            tau_old=tau;
            taut_old=taut;
            tmp_inverse=II/(II-tau_old*taut_old-taut_old*tau_old);
            tau=tmp_inverse*tau_old^2;
            taut=tmp_inverse*taut_old^2;
            cnvg_tau=sum(sum(abs(tau),1),2);
            cnvg_taut=sum(sum(abs(taut),1),2);
            if ((cnvg_tau<1e-7) && (cnvg_taut<1e-7))
                break;
            end
        end
        Gy=II/(omega-H00-H01*tot);
        DOS(index)=-1/pi*imag(trace(Gy));   
        %for icut=1:ih
        %    for iatom=1:8
        %        index11=(icut-1)*N_HAM+(iatom-1)*3+1;
        %        DOS_proj(index,(icut-1)*8+iatom)=-1/pi*imag(trace(Gy(index11:index11+2,index11:index11+2))...
        %            +trace(Gy(index11+24:index11+24+2,index11+24:index11+24+2)));
        %    end
        %end
    
        message = sprintf('k-point:%d/%d, Time:%6.2f second',(ik-1)*size(Energy,2)+index,size(Kline,1)*size(Energy,2),toc(tSTART));
        disp(message);
    end
    LDOS(:,ik)=DOS;
    %for icut=1:ih
    %    for iatom=1:8
    %        LDOS_proj(:,(icut-1)*8+iatom,ik)=DOS_proj(:,(icut-1)*8+iatom);
    %    end
    %end
end

%% plot and save data
kpath=0:2*(size(Kline,1)-1)+1;
[kmesh,Emesh]=meshgrid(kpath,Energy-Ef);
LDOS2=[fliplr(LDOS),LDOS];

figure
h=pcolor(kmesh,Emesh,LDOS2); 
set(h,'edgecolor','none');
axis([0 (size(kpath,2)-1) -0.15 -0.05]);
caxis([0 100]);colormap(hot);
ylabel("Energy (eV)");
xticks([0 (size(kpath,2)-1)/2 (size(kpath,2)-1)]); 
xticklabels({' \Gamma_1 ',' Z ', '\Gamma_2'});
set(gca,'FontName','Times New Roman','FontSize', 18)
savefig('LDOS.fig');

filename = ['LDOS','.txt'];
save(filename, 'LDOS','-ascii');

%% Appendix
function T = T3(V_pps, V_ppp,l, m, n)
T = zeros(3,3);

T(1,1) = l ^ 2 * V_pps + (1 - l ^ 2) * V_ppp;
T(1,2) = l * m * (V_pps - V_ppp); T(2,1) = T(1,2);
T(1,3) = l * n * (V_pps - V_ppp); T(3,1) = T(1,3);

T(2,2) = m ^ 2 * V_pps + (1 - m ^ 2) * V_ppp;
T(2,3) = m * n * (V_pps - V_ppp); T(3,2) = T(2,3);

T(3,3) = n ^ 2 * V_pps + (1 - n ^ 2) * V_ppp;

end

%% hopping term; geometry
function [H] = hopping(atom1,atom2,R,H)
V_pps = 0.9;
V_ppp = 0.0;
V_pps1 =  0.5; % 0.5 for Sn, -0.5 for Te
V_ppp1 =  0.0;

atom_list = [0.0, 0.0, 0.0;
             0.5, 0.0, 0.0;
             0.5, 0.5, 0.0;
             0.0, 0.5, 0.0;
             0.5, 0.0, 0.5;
             0.5, 0.5, 0.5;
             0.0, 0.5, 0.5;
             0.0, 0.0, 0.5;];
T = zeros(3,3);
vec = atom_list(atom2,:)-atom_list(atom1,:)+R;
vec1 = vec(1)/norm(vec);
vec2 = vec(2)/norm(vec);
vec3 = vec(3)/norm(vec);

if norm(vec) < sqrt(3)/2
    if mod(atom1+atom2,2)
        T = T3(V_pps,V_ppp,vec1,vec2,vec3);
    elseif mod(atom1,2)
        T = T3(V_pps1,V_ppp1,vec1,vec2,vec3);
    else
        T = T3(-V_pps1,-V_ppp1,vec1,vec2,vec3);
    end
end

H(1+3*(atom1-1):3*atom1,1+3*(atom2-1):3*atom2) = H(1+3*(atom1-1):3*atom1,1+3*(atom2-1):3*atom2) + T;
end

%% function H
function [HAM_R,LX,LY,LZ] = hamk1()
m = 1.65; % m for Sn, -m for Te
soc = 0.7;

delta = -0.4; % -0.4
onsite_delta = [0,delta,0;delta,0,0;0,0,0];

HAM_R = zeros(48,48,27);
LX = zeros(48,48,27);
LY = zeros(48,48,27);
LZ = zeros(48,48,27);

lx = [0,0,0;0,0,-1i;0,1i,0];
ly = [0,0,1i;0,0,0;-1i,0,0];
lz = [0,-1i,0;1i,0,0;0,0,0];

Lx = kron(eye(8),lx);
Ly = kron(eye(8),ly);
Lz = kron(eye(8),lz);

sigma_x = [0,1;1,0];
sigma_y = [0,-1i;1i,0];
sigma_z = [1,0;0,-1];

for ix=-1:1
    for iy=-1:1
        for iz=-1:1
            ih = (ix+1)*9+(iy+1)*3+(iz+1)+1;
            R = [ix,iy,iz];
            H_tmp = zeros(24,24);
            for iatom1 = 1:8
                for iatom2 = 1:8
                    H_tmp = hopping(iatom1,iatom2,R,H_tmp);
                end
            end
            if norm(R) == 0
                for i=1:4
                    i1 = 6*i-5;
                    i2 = 6*i-2;
                    H_tmp(i1:i1+2,i1:i1+2) =  m*eye(3)+[0,0,0;0,0,0;0,0,0]+onsite_delta;
                    H_tmp(i2:i2+2,i2:i2+2) = -m*eye(3)+onsite_delta;
                end
            end
            HAM_R(:,:,ih) = kron(eye(2),H_tmp);
            if norm(R) == 0
                HAM_R(:,:,ih) = HAM_R(:,:,ih)+soc*(kron(sigma_z,Lz)+kron(sigma_x,Lx)+kron(sigma_y,Ly));
            end
            LX(:,:,ih) = ix*ones(48);
            LY(:,:,ih) = iy*ones(48);
            LZ(:,:,ih) = iz*ones(48);
        end
    end
end

end
