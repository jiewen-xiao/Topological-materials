function [H_tb]=Ham_rod(kz,LX,LY,LZ,N_HAM,HAM_R,xcut,ycut)

li=1*i;

%% GET the hopping in x direction

% find LZ=0 for extracting H0 
index_x=find(LX(1,1,:)==0);
index_y=find(LY(1,1,:)==0);
index=intersect(index_x,index_y);
h0=exp(li*(LZ(:,:,index)*kz)).*HAM_R(:,:,index);
H0=reshape(sum(h0,3),N_HAM,N_HAM);
H0=(H0'+H0)/2;  % Hermite matrix


% find LZ=iz for extracting T(iz) of the iz order of neighbors
xmax=max(max(max(LX)));
ymax=max(max(max(LY)));
if xcut>xmax
    xmax=xcut;
end
if ycut>ymax
    ymax=ycut;
end
T=zeros(2*xmax+1,2*ymax+1,N_HAM,N_HAM);

for ix=-xmax:xmax
    for iy=-ymax:ymax
        index_x=find(LX(1,1,:)==ix);
        index_y=find(LY(1,1,:)==iy);
        index1=intersect(index_x,index_y);
        t=exp(li*(LZ(:,:,index1)*kz)).*HAM_R(:,:,index1);
        T(ix+1+xmax,iy+1+ymax,:,:)=reshape(sum(t,3),N_HAM,N_HAM);
    end
end

%% construct H00 and H01
H_tb=kron(eye((xcut+1)*(ycut+1)),H0);

for ix=0:xcut
    for iy=0:ycut
        ih=ix*(ycut+1)+iy;
        
        for ix1=0:xcut
            for iy1=0:ycut
                ih1 = ix1*(ycut+1)+iy1;
                if ih1>ih
                    ixx=ix1-ix;
                    iyy=iy1-iy;
                    TT=reshape(T(ixx+1+xmax,iyy+1+ymax,:,:),N_HAM,N_HAM);
                    H_tb(1+ih*N_HAM:(ih+1)*N_HAM,1+ih1*N_HAM:(ih1+1)*N_HAM)=TT;
                    H_tb(1+ih1*N_HAM:(ih1+1)*N_HAM,1+ih*N_HAM:(ih+1)*N_HAM)=TT';
                end
            end
        end

    end
end


end