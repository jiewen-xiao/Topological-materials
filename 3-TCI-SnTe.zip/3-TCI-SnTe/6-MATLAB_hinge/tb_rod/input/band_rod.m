% Green function method
% ref. 1984
%% READ the wannier hamiltonian
clear all;
li=i;
eta=1e-45;
epsilon=1e-4;

N_HAM = 48;
[HAM_R,LX,LY,LZ] = hamk1();
xcut=16;
ycut=16;
ih = (xcut+1)*(ycut+1);
N_HAM_rod = N_HAM*ih;
Nvalence = 24*ih;

% Proj=zeros(N_HAM_rod,N_HAM_rod,ih);
% for iproj=1:ih
%     Proj((iproj-1)*N_HAM+1:iproj*N_HAM,(iproj-1)*N_HAM+1:iproj*N_HAM,iproj) = eye(N_HAM);
% end
    
%% TEST: Calculate the bulk band structure 
kline=[   0.000 0.000  0.350;  
          0.000 0.000  0.500;]*2*pi;
Ngrid=101;
Kline=zeros((size(kline,1)-1)*(Ngrid-1)+1,3);
for ikline=1:(size(kline,1)-1)
    tmp=linspaceNDim(kline(ikline,:),kline(ikline+1,:),Ngrid);
    tmp2=tmp';
    Kline((ikline-1)*(Ngrid-1)+1:ikline*(Ngrid-1),:)=tmp2(1:Ngrid-1,:);
end
Kline((size(kline,1)-1)*(Ngrid-1)+1,:)=kline(size(kline,1),:);

Ek=zeros((size(kline,1)-1)*(Ngrid-1)+1,N_HAM_rod);
Ek_proj = zeros((size(kline,1)-1)*(Ngrid-1)+1,N_HAM_rod,ih);

for ik=1:size(Kline,1)
    tSTART=tic;
        
    kx=Kline(ik,1);
    ky=Kline(ik,2);
    kz=Kline(ik,3);
    
    H_tb = Ham_rod(kz,LX,LY,LZ,N_HAM,HAM_R,xcut,ycut);
    Hk=(H_tb'+H_tb)/2; 
        
    [Wavek,energy_tmp]=eig(Hk);
    energy=diag(energy_tmp);
    Ek(ik,:)=energy';
    
%     for iproj=1:ih
%         Ek_proj(ik,:,iproj) = diag(Wavek'*Proj(:,:,iproj)*Wavek)';
%     end
        
    message = sprintf('k-point:%3d/%3d, Time:%6.2f second',ik,size(Kline,1),toc(tSTART));
    disp(message);
end
Ef = (max(Ek(:,Nvalence))+min(Ek(:,Nvalence+1)))/2; % center of CBM+VBM

%% figure and save data
Ek0 = [Ek',fliplr(Ek')]';
figure
for iband=1:N_HAM_rod
    M = plot(0:(size(Ek,1)-1)*2+1,Ek0(:,iband)-Ef,'b');hold on;
    set(M,'linewidth',2);
end
axis([0 2*size(Ek,1)-1 -0.4  +0.4]);
xticks([0 size(Ek,1) 2*size(Ek,1)-1]);
xticklabels({'\Gamma', 'Z', ' \Gamma '});
ylabel('Energy (eV)'); 
set(gca,'FontName','Times New Roman','FontSize', 16,'fontweight','b');
savefig('band_rod.fig');

save data
filename1 = ['Ek','.txt'];
save(filename1, 'Ek','-ascii');

%% Appendix
function T = T3(V_pps, V_ppp,l, m, n)
T = zeros(3,3);

T(1,1) = l ^ 2 * V_pps + (1 - l ^ 2) * V_ppp;
T(1,2) = l * m * (V_pps - V_ppp); T(2,1) = T(1,2);
T(1,3) = l * n * (V_pps - V_ppp); T(3,1) = T(1,3);

T(2,2) = m ^ 2 * V_pps + (1 - m ^ 2) * V_ppp;
T(2,3) = m * n * (V_pps - V_ppp); T(3,2) = T(2,3);

T(3,3) = n ^ 2 * V_pps + (1 - n ^ 2) * V_ppp;

end

%% hopping term; geometry
function [H] = hopping(atom1,atom2,R,H)
V_pps = 0.9;
V_ppp = 0.0;
V_pps1 =  0.5; % 0.5 for Sn, -0.5 for Te
V_ppp1 =  0.0;

atom_list = [0.0, 0.0, 0.0;
             0.5, 0.0, 0.0;
             0.5, 0.5, 0.0;
             0.0, 0.5, 0.0;
             0.5, 0.0, 0.5;
             0.5, 0.5, 0.5;
             0.0, 0.5, 0.5;
             0.0, 0.0, 0.5;];
T = zeros(3,3);
vec = atom_list(atom2,:)-atom_list(atom1,:)+R;
vec1 = vec(1)/norm(vec);
vec2 = vec(2)/norm(vec);
vec3 = vec(3)/norm(vec);

if norm(vec) < sqrt(3)/2
    if mod(atom1+atom2,2)
        T = T3(V_pps,V_ppp,vec1,vec2,vec3);
    elseif mod(atom1,2)
        T = T3(V_pps1,V_ppp1,vec1,vec2,vec3);
    else
        T = T3(-V_pps1,-V_ppp1,vec1,vec2,vec3);
    end
end

H(1+3*(atom1-1):3*atom1,1+3*(atom2-1):3*atom2) = H(1+3*(atom1-1):3*atom1,1+3*(atom2-1):3*atom2) + T;
end

%% function H
function [HAM_R,LX,LY,LZ] = hamk1()
m = 1.65; % m for Sn, -m for Te
soc = 0.7;

delta = -0.5; % -0.4
onsite_delta = [0,delta,0;delta,0,0;0,0,0];

HAM_R = zeros(48,48,27);
LX = zeros(48,48,27);
LY = zeros(48,48,27);
LZ = zeros(48,48,27);

lx = [0,0,0;0,0,-1i;0,1i,0];
ly = [0,0,1i;0,0,0;-1i,0,0];
lz = [0,-1i,0;1i,0,0;0,0,0];

Lx = kron(eye(8),lx);
Ly = kron(eye(8),ly);
Lz = kron(eye(8),lz);

sigma_x = [0,1;1,0];
sigma_y = [0,-1i;1i,0];
sigma_z = [1,0;0,-1];

for ix=-1:1
    for iy=-1:1
        for iz=-1:1
            ih = (ix+1)*9+(iy+1)*3+(iz+1)+1;
            R = [ix,iy,iz];
            H_tmp = zeros(24,24);
            for iatom1 = 1:8
                for iatom2 = 1:8
                    H_tmp = hopping(iatom1,iatom2,R,H_tmp);
                end
            end
            if norm(R) == 0
                for i=1:4
                    i1 = 6*i-5;
                    i2 = 6*i-2;
                    H_tmp(i1:i1+2,i1:i1+2) =  m*eye(3) + onsite_delta;
                    H_tmp(i2:i2+2,i2:i2+2) = -m*eye(3) + onsite_delta;
                end
            end
            HAM_R(:,:,ih) = kron(eye(2),H_tmp);
            if norm(R) == 0
                HAM_R(:,:,ih) = HAM_R(:,:,ih)+soc*(kron(sigma_z,Lz)+kron(sigma_x,Lx)+kron(sigma_y,Ly));
            end
            LX(:,:,ih) = ix*ones(48);
            LY(:,:,ih) = iy*ones(48);
            LZ(:,:,ih) = iz*ones(48);
        end
    end
end

end
