%% my read pattern
clear all
li=i;
disp('Start reading wannier90_hr.dat');
tic;

filehr = fopen('./wannier90_hr.dat');
head=textscan(filehr,'%s %s %s %s %s',1);
n_ham=textscan(filehr,'%d',1);
N_HAM=cell2mat(n_ham);           %dimensions of the HAM
n_latt=textscan(filehr,'%d',1);  %total number of neighboring sites
N_LATT=cell2mat(n_latt);
% degeneracy of a site, HAM_R should be scaled by 1/DGN.
dgn=textscan(filehr,'%f',N_LATT);
DGN=cell2mat(dgn)'; % DNG is a row matrix
% read LX,LY,LZ,HAM_R(real,img), and omit (n,m) of HAM_R_nm
data=textscan(filehr,'%f %f %f %*d %*d %10.6f %10.6f',N_HAM*N_HAM*N_LATT);
DATA=cell2mat(data);
load 'wann.dat';
HAM_R1=wann(:,6)+1i*wann(:,7);
% reshape HAM_R, a column contains the HAM matrix (1-N_HAM*N_HAM) for
% a neiboring site n_latt (column index,1-N_LATT)
HAM_R2=reshape(HAM_R1, N_HAM*N_HAM,N_LATT);
% scale HAM_R by the degeneracy (1/DGN)
HAM_R2=HAM_R2./kron(ones(N_HAM*N_HAM,1),DGN);
%%% change to new format, so is the func_surface.m
HAM_R=reshape(HAM_R2,N_HAM,N_HAM,N_LATT);
Lx=reshape(wann(:,1),N_HAM,N_HAM,N_LATT);
Ly=reshape(wann(:,2),N_HAM,N_HAM,N_LATT);
Lz=reshape(wann(:,3),N_HAM,N_HAM,N_LATT);
fclose(filehr);
disp('Complete reading the Hamiltonian from wannier90_hr.dat');
toc;
% make no rotation 
L1=Lx;
L2=Ly;
L3=Lz;
%% mirror operator, point like M_xy (1-10) mirror
sigma_x = [0,1;1,0];
sigma_y = [0,-1i;1i,0];
sigma_z = [1,0;0,-1];

n = [1,-1,0]/sqrt(2);
alpha = pi;
R_spin = eye(2)*cos(alpha/2)-1i*(n(1)*sigma_x+n(2)*sigma_y+n(3)*sigma_z)*sin(alpha/2);

mxy = [1,0,0;0,0,1;0,1,0];
Mxy = kron(R_spin,kron(eye(2),mxy));

%% M_x-y (110) mirror
n1 = [1,1,0]/sqrt(2);
alpha1 = pi;
R_spin1 = eye(2)*cos(alpha1/2)-1i*(n1(1)*sigma_x+n1(2)*sigma_y+n1(3)*sigma_z)*sin(alpha1/2);

mxy1 = [1,0,0;0,0,-1;0,-1,0];
Mxy1 = kron(R_spin1,kron(eye(2),mxy1));

M1_latt = kron(eye(2),[zeros(3),zeros(3);zeros(3),zeros(3)]);
M2_latt = kron(eye(2),[zeros(3),zeros(3);zeros(3),zeros(3)]);
M3_latt = kron(eye(2),[2*ones(3),zeros(3);zeros(3),zeros(3)]);
%%
Nvalence=6/2;
Klist_i=(0.0:1/200:1.0)*2*pi; % integration
Klist_d=(0.0:1/1200:1.0)*2*pi; % dispersion
%lattic coordinates
% a1 = [0 1 1]; a2 = [1 0 1]; a3 = [1 1 0]
% b1 = [-1 1 1]; b2 = [1 -1 1]; b3 = [1 1 -1]
%Mxy
% k_i = [1, 1, 1];
% k_d = [-1/3, -1/3, 2/3];
%Mx_y1 (110) plane
k_i = [1, 1, 0];
k_d = [-0.5, 0.5, 0];

theta=zeros(size(Klist_d,2),Nvalence);
theta_a=zeros(size(Klist_d,2),Nvalence);

for ik1=1:size(Klist_d,2)
    k1 = Klist_d(ik1);
    tSTART=tic;
    WL = eye(Nvalence);
    WL_a = eye(Nvalence);
    for ik2=1:size(Klist_i,2) %% integral along this direction, i.e. Wilson-loop
        ik20 = ik2;
        if ik2 == size(Klist_i,2)
            ik2 = 1;
        end
        k2 = Klist_i(ik2);
        
        kx = k1*k_d(1)+k2*k_i(1);
        ky = k1*k_d(2)+k2*k_i(2);
        kz = k1*k_d(3)+k2*k_i(3);
        h0=exp(li*(L1*kx+L2*ky+L3*kz)).*HAM_R;
        
        H0=reshape(sum(h0,3),N_HAM,N_HAM);
        Hk=(H0'+H0)/2;    
        

        Mxy1_k = exp(li*(M1_latt*kx+M1_latt*ky+M1_latt*kz)).*Mxy1;
        [Wavek,energy_tmp]=eig(Mxy1_k*Hk);
%         [Wavek,energy_tmp]=eig(Mxy*Hk);

        Ek_tmp = imag(diag(energy_tmp));
        [Ek_tmp,id] = sort(Ek_tmp);
        Wavek_sort = Wavek(:,id);
        m1=Wavek_sort(:,7:9);
        m1_a=Wavek_sort(:,4:6);

        if ik20>1
            WL=WL*(m0'*m1); % m0'*m1=<i|i+1>
            WL_a=WL_a*(m0_a'*m1_a);
        end
        m0=m1;
        m0_a=m1_a;
    end
    theta(ik1,:)=-imag(log(eig(WL)));
    theta_a(ik1,:)=-imag(log(eig(WL_a)));
    message = sprintf('k1:%3d/%3d, Time:%6.2f second',ik1,size(Klist_d,2),toc(tSTART));
    disp(message);
end

%%
figure
plot(Klist_d/(2*pi),theta(:,1:Nvalence)/(2*pi),'r.'); hold on;
plot(Klist_d/(2*pi),theta_a(:,1:Nvalence)/(2*pi),'b.');
xlim([-0.0 1.0]);
ylim([-0.5 0.5]);
xticks([0.0 0.5 1.0]);
yticks([-0.5 0.0 0.5]);
ylabel('\theta (2\pi)');
